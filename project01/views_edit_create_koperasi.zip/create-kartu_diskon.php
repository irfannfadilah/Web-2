
<?php
require_once __DIR__ . '/../models/kartu_diskon.php';
use models\Kartu_diskon;

if(isset($_GET['id'])) {
    $data = Kartu_diskon::find($_GET['id']);
    if(!$data) {
        header("Location: list-kartu_diskon.php");
        exit;
    }
} else {
    $data = array_fill_keys(['nama', 'deskripsi', 'persen_diskon'], '');
}

if(isset($_POST['submit'])) {
    $payload = ['id' => $_GET['id'] ?? null];
    $payload['nama'] = $_POST['nama'];
    $payload['deskripsi'] = $_POST['deskripsi'];
    $payload['persen_diskon'] = $_POST['persen_diskon'];
    if(isset($_GET['id'])) {
        Kartu_diskon::update(array_merge($payload));
    } else {
        Kartu_diskon::create(array_merge($payload));
    }
    header("Location: list-kartu_diskon.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit/Create Kartu_diskon</title></head>
<body>
    <h2><?= isset($_GET['id']) ? 'Edit' : 'Create' ?> Kartu_diskon</h2>
    <form method="POST">
<label>Nama</label><input type="text" name="nama" value="<?= $data["nama"] ?>"><br>
<label>Deskripsi</label><input type="text" name="deskripsi" value="<?= $data["deskripsi"] ?>"><br>
<label>Persen Diskon</label><input type="text" name="persen_diskon" value="<?= $data["persen_diskon"] ?>"><br>
        <button type="submit" name="submit">Save</button>
    </form>
    <a href="list-kartu_diskon.php">Back to List</a>
</body>
</html>
