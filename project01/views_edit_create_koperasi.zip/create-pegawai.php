
<?php
require_once __DIR__ . '/../models/pegawai.php';
use models\Pegawai;

if(isset($_GET['id'])) {
    $data = Pegawai::find($_GET['id']);
    if(!$data) {
        header("Location: list-pegawai.php");
        exit;
    }
} else {
    $data = array_fill_keys(['nip', 'nama', 'jenis_kelamin', 'jabatan'], '');
}

if(isset($_POST['submit'])) {
    $payload = ['id' => $_GET['id'] ?? null];
    $payload['nip'] = $_POST['nip'];
    $payload['nama'] = $_POST['nama'];
    $payload['jenis_kelamin'] = $_POST['jenis_kelamin'];
    $payload['jabatan'] = $_POST['jabatan'];
    if(isset($_GET['id'])) {
        Pegawai::update(array_merge($payload));
    } else {
        Pegawai::create(array_merge($payload));
    }
    header("Location: list-pegawai.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit/Create Pegawai</title></head>
<body>
    <h2><?= isset($_GET['id']) ? 'Edit' : 'Create' ?> Pegawai</h2>
    <form method="POST">
<label>Nip</label><input type="text" name="nip" value="<?= $data["nip"] ?>"><br>
<label>Nama</label><input type="text" name="nama" value="<?= $data["nama"] ?>"><br>
<label>Jenis Kelamin</label><input type="text" name="jenis_kelamin" value="<?= $data["jenis_kelamin"] ?>"><br>
<label>Jabatan</label><input type="text" name="jabatan" value="<?= $data["jabatan"] ?>"><br>
        <button type="submit" name="submit">Save</button>
    </form>
    <a href="list-pegawai.php">Back to List</a>
</body>
</html>
