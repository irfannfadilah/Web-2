
<?php
require_once __DIR__ . '/../models/produk.php';
use models\Produk;

if(isset($_GET['id'])) {
    $data = Produk::find($_GET['id']);
    if(!$data) {
        header("Location: list-produk.php");
        exit;
    }
} else {
    $data = array_fill_keys(['kode', 'nama', 'deskripsi', 'harga', 'stok', 'jenis_produk_id'], '');
}

if(isset($_POST['submit'])) {
    $payload = ['id' => $_GET['id'] ?? null];
    $payload['kode'] = $_POST['kode'];
    $payload['nama'] = $_POST['nama'];
    $payload['deskripsi'] = $_POST['deskripsi'];
    $payload['harga'] = $_POST['harga'];
    $payload['stok'] = $_POST['stok'];
    $payload['jenis_produk_id'] = $_POST['jenis_produk_id'];
    if(isset($_GET['id'])) {
        Produk::update(array_merge($payload));
    } else {
        Produk::create(array_merge($payload));
    }
    header("Location: list-produk.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit/Create Produk</title></head>
<body>
    <h2><?= isset($_GET['id']) ? 'Edit' : 'Create' ?> Produk</h2>
    <form method="POST">
<label>Kode</label><input type="text" name="kode" value="<?= $data["kode"] ?>"><br>
<label>Nama</label><input type="text" name="nama" value="<?= $data["nama"] ?>"><br>
<label>Deskripsi</label><input type="text" name="deskripsi" value="<?= $data["deskripsi"] ?>"><br>
<label>Harga</label><input type="text" name="harga" value="<?= $data["harga"] ?>"><br>
<label>Stok</label><input type="text" name="stok" value="<?= $data["stok"] ?>"><br>
<label>Jenis Produk Id</label><input type="text" name="jenis_produk_id" value="<?= $data["jenis_produk_id"] ?>"><br>
        <button type="submit" name="submit">Save</button>
    </form>
    <a href="list-produk.php">Back to List</a>
</body>
</html>
