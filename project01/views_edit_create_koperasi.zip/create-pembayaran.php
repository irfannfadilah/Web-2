
<?php
require_once __DIR__ . '/../models/pembayaran.php';
use models\Pembayaran;

if(isset($_GET['id'])) {
    $data = Pembayaran::find($_GET['id']);
    if(!$data) {
        header("Location: list-pembayaran.php");
        exit;
    }
} else {
    $data = array_fill_keys(['jumlah_bayar', 'tanggal', 'pesanan_id'], '');
}

if(isset($_POST['submit'])) {
    $payload = ['id' => $_GET['id'] ?? null];
    $payload['jumlah_bayar'] = $_POST['jumlah_bayar'];
    $payload['tanggal'] = $_POST['tanggal'];
    $payload['pesanan_id'] = $_POST['pesanan_id'];
    if(isset($_GET['id'])) {
        Pembayaran::update(array_merge($payload));
    } else {
        Pembayaran::create(array_merge($payload));
    }
    header("Location: list-pembayaran.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit/Create Pembayaran</title></head>
<body>
    <h2><?= isset($_GET['id']) ? 'Edit' : 'Create' ?> Pembayaran</h2>
    <form method="POST">
<label>Jumlah Bayar</label><input type="text" name="jumlah_bayar" value="<?= $data["jumlah_bayar"] ?>"><br>
<label>Tanggal</label><input type="text" name="tanggal" value="<?= $data["tanggal"] ?>"><br>
<label>Pesanan Id</label><input type="text" name="pesanan_id" value="<?= $data["pesanan_id"] ?>"><br>
        <button type="submit" name="submit">Save</button>
    </form>
    <a href="list-pembayaran.php">Back to List</a>
</body>
</html>
