
<?php
require_once __DIR__ . '/../models/pesanan.php';
use models\Pesanan;

if(isset($_GET['id'])) {
    $data = Pesanan::find($_GET['id']);
    if(!$data) {
        header("Location: list-pesanan.php");
        exit;
    }
} else {
    $data = array_fill_keys(['tanggal', 'diskon', 'status_bayar', 'anggota_id'], '');
}

if(isset($_POST['submit'])) {
    $payload = ['id' => $_GET['id'] ?? null];
    $payload['tanggal'] = $_POST['tanggal'];
    $payload['diskon'] = $_POST['diskon'];
    $payload['status_bayar'] = $_POST['status_bayar'];
    $payload['anggota_id'] = $_POST['anggota_id'];
    if(isset($_GET['id'])) {
        Pesanan::update(array_merge($payload));
    } else {
        Pesanan::create(array_merge($payload));
    }
    header("Location: list-pesanan.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit/Create Pesanan</title></head>
<body>
    <h2><?= isset($_GET['id']) ? 'Edit' : 'Create' ?> Pesanan</h2>
    <form method="POST">
<label>Tanggal</label><input type="text" name="tanggal" value="<?= $data["tanggal"] ?>"><br>
<label>Diskon</label><input type="text" name="diskon" value="<?= $data["diskon"] ?>"><br>
<label>Status Bayar</label><input type="text" name="status_bayar" value="<?= $data["status_bayar"] ?>"><br>
<label>Anggota Id</label><input type="text" name="anggota_id" value="<?= $data["anggota_id"] ?>"><br>
        <button type="submit" name="submit">Save</button>
    </form>
    <a href="list-pesanan.php">Back to List</a>
</body>
</html>
