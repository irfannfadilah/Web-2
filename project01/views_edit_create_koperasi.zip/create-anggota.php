
<?php
require_once __DIR__ . '/../models/anggota.php';
use models\Anggota;

if(isset($_GET['id'])) {
    $data = Anggota::find($_GET['id']);
    if(!$data) {
        header("Location: list-anggota.php");
        exit;
    }
} else {
    $data = array_fill_keys(['status_aktif', 'pegawai_id', 'kartu_diskon_id'], '');
}

if(isset($_POST['submit'])) {
    $payload = ['id' => $_GET['id'] ?? null];
    $payload['status_aktif'] = $_POST['status_aktif'];
    $payload['pegawai_id'] = $_POST['pegawai_id'];
    $payload['kartu_diskon_id'] = $_POST['kartu_diskon_id'];
    if(isset($_GET['id'])) {
        Anggota::update(array_merge($payload));
    } else {
        Anggota::create(array_merge($payload));
    }
    header("Location: list-anggota.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit/Create Anggota</title></head>
<body>
    <h2><?= isset($_GET['id']) ? 'Edit' : 'Create' ?> Anggota</h2>
    <form method="POST">
<label>Status Aktif</label><input type="text" name="status_aktif" value="<?= $data["status_aktif"] ?>"><br>
<label>Pegawai Id</label><input type="text" name="pegawai_id" value="<?= $data["pegawai_id"] ?>"><br>
<label>Kartu Diskon Id</label><input type="text" name="kartu_diskon_id" value="<?= $data["kartu_diskon_id"] ?>"><br>
        <button type="submit" name="submit">Save</button>
    </form>
    <a href="list-anggota.php">Back to List</a>
</body>
</html>
