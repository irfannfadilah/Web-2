
<?php
require_once __DIR__ . '/../models/jenis_produk.php';
use models\Jenis_produk;

if(isset($_GET['id'])) {
    $data = Jenis_produk::find($_GET['id']);
    if(!$data) {
        header("Location: list-jenis_produk.php");
        exit;
    }
} else {
    $data = array_fill_keys(['nama', 'deskripsi'], '');
}

if(isset($_POST['submit'])) {
    $payload = ['id' => $_GET['id'] ?? null];
    $payload['nama'] = $_POST['nama'];
    $payload['deskripsi'] = $_POST['deskripsi'];
    if(isset($_GET['id'])) {
        Jenis_produk::update(array_merge($payload));
    } else {
        Jenis_produk::create(array_merge($payload));
    }
    header("Location: list-jenis_produk.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Edit/Create Jenis_produk</title></head>
<body>
    <h2><?= isset($_GET['id']) ? 'Edit' : 'Create' ?> Jenis_produk</h2>
    <form method="POST">
<label>Nama</label><input type="text" name="nama" value="<?= $data["nama"] ?>"><br>
<label>Deskripsi</label><input type="text" name="deskripsi" value="<?= $data["deskripsi"] ?>"><br>
        <button type="submit" name="submit">Save</button>
    </form>
    <a href="list-jenis_produk.php">Back to List</a>
</body>
</html>
